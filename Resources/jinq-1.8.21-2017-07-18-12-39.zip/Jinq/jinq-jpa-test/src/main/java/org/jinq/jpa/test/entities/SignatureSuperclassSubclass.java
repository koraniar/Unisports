package org.jinq.jpa.test.entities;

import javax.persistence.MappedSuperclass;

@MappedSuperclass
public class SignatureSuperclassSubclass extends SignatureSuperclass
{

}
