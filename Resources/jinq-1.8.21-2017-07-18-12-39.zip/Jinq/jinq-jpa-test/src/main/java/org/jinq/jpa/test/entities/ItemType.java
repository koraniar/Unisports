package org.jinq.jpa.test.entities;

public enum ItemType 
{
   SMALL, BIG, OTHER
}
