package ch.epfl.labos.iu.orm.queryll2.path;

public class MethodSideEffect
{

}
