package org.jinq.jpa.transform;

public class JPQLQueryTransformConfigurationFactory
{
   public JPQLQueryTransformConfiguration createConfig()
   {
      return new JPQLQueryTransformConfiguration();
   }
}
