package com.example.jinq.sample.jpa.entities;

public enum ItemType 
{
   SMALL, BIG, OTHER
}
