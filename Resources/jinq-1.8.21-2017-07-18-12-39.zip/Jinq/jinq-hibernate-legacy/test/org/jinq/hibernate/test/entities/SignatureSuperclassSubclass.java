package org.jinq.hibernate.test.entities;

import javax.persistence.MappedSuperclass;

@MappedSuperclass
public class SignatureSuperclassSubclass extends SignatureSuperclass
{

}
